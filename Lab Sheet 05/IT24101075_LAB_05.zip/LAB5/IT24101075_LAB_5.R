getwd()
setwd("C:\\Users\\it24101075\\Desktop\\LAB5")
#importing the data set
data<-read.table("Exercise - Lab 05.txt",header = TRUE,sep = ",")

#view file in seperate window
fix(data)
#Attach the files into the R, so we can call variables by their name
attach(data)

names(data) <- c("X1")
attach(data)
X1


histogram<-hist(X1,main ="histogram for deliver times",breaks = seq(20,70,length=10),right =FALSE)

#part 4
#assign class limits of the frequency distribution
breaks <- round(histogram$breaks)
breaks
#Assign class frquencies of the histogram into a variable
freq <- histogram$counts
freq
#Using cumsum command we can get cumulative frequencies
cum.freq <- cumsum(freq)
cum.freq
new <- c()
for(i in 1:length(breaks)){
  if(i==1){
    new[i] =0
  }else{
    new[i] = cum.freq[i-1]
  }
}

plot(breaks,new,type = 'o',main = " cumulative frequency polygon for deliver time(x1)",
     xlab = "Deliver Time", ylab = "Cumulative Frequency",ylim = c(0,max(cum.freq)))
